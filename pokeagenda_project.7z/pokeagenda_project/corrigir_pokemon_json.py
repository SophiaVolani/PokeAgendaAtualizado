#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
corrigir_pokemon_json.py

→ Lê o arquivo pokemon_static_fixed.json
→ Lê missing_manual_fill.txt
→ Preenche nome, tipos, altura e peso CORRETOS
→ Gera pokemon_static_fixed_CORRIGIDO.json
→ Não usa internet
"""

import json
import re

# -------------------------------
# 1. BANCO DE DADOS OFFLINE COMPLETO
# -------------------------------
# Contém: nome, tipos, altura, peso
# para TODOS os 1025 Pokémon
# (versão compacta, carregada via dicionário interno)
# --------------------------------

# ⚠️ IMPORTANTE:
# Para não ultrapassar limite da plataforma, vou gerar ESSE BLOCO
# quando você disser: **"pode gerar a pokedex offline"**
# (São ~120 KB apenas deste bloco)

# Por agora, deixo criado o container vazio:
POKEDEX = {
    {
    "id": 1,
    "dex": 1,
    "name": "#001 Bulbasaur",
    "types": ["grass", "poison"],
    "height": 0.7,
    "weight": 6.9,
    "sprite": "/static/sprites/1.png"
  },
  {
    "id": 2,
    "dex": 2,
    "name": "#002 Ivysaur",
    "types": ["grass", "poison"],
    "height": 1.0,
    "weight": 13.0,
    "sprite": "/static/sprites/2.png"
  },
  {
    "id": 3,
    "dex": 3,
    "name": "#003 Venusaur",
    "types": ["grass", "poison"],
    "height": 2.0,
    "weight": 100.0,
    "sprite": "/static/sprites/3.png"
  },
  {
    "id": 3_01,
    "dex": 3,
    "name": "#003 Venusaur Mega",
    "types": ["grass", "poison"],
    "height": 2.4,
    "weight": 155.5,
    "sprite": "/static/sprites/3-mega.png"
  },
  {
    "id": 4,
    "dex": 4,
    "name": "#004 Charmander",
    "types": ["fire"],
    "height": 0.6,
    "weight": 8.5,
    "sprite": "/static/sprites/4.png"
  },
  {
    "id": 5,
    "dex": 5,
    "name": "#005 Charmeleon",
    "types": ["fire"],
    "height": 1.1,
    "weight": 19.0,
    "sprite": "/static/sprites/5.png"
  },
  {
    "id": 6,
    "dex": 6,
    "name": "#006 Charizard",
    "types": ["fire", "flying"],
    "height": 1.7,
    "weight": 90.5,
    "sprite": "/static/sprites/6.png"
  },
  {
    "id": 6_01,
    "dex": 6,
    "name": "#006 Charizard Mega X",
    "types": ["fire", "dragon"],
    "height": 1.7,
    "weight": 110.5,
    "sprite": "/static/sprites/6-megax.png"
  },
  {
    "id": 6_02,
    "dex": 6,
    "name": "#006 Charizard Mega Y",
    "types": ["fire", "flying"],
    "height": 1.7,
    "weight": 100.5,
    "sprite": "/static/sprites/6-megay.png"
  },
  {
    "id": 7,
    "dex": 7,
    "name": "#007 Squirtle",
    "types": ["water"],
    "height": 0.5,
    "weight": 9.0,
    "sprite": "/static/sprites/7.png"
  },
  {
    "id": 8,
    "dex": 8,
    "name": "#008 Wartortle",
    "types": ["water"],
    "height": 1.0,
    "weight": 22.5,
    "sprite": "/static/sprites/8.png"
  },
  {
    "id": 9,
    "dex": 9,
    "name": "#009 Blastoise",
    "types": ["water"],
    "height": 1.6,
    "weight": 85.5,
    "sprite": "/static/sprites/9.png"
  },
  {
    "id": 9_01,
    "dex": 9,
    "name": "#009 Blastoise Mega",
    "types": ["water"],
    "height": 1.6,
    "weight": 101.1,
    "sprite": "/static/sprites/9-mega.png"
  },
  {
    "id": 10,
    "dex": 10,
    "name": "#010 Caterpie",
    "types": ["bug"],
    "height": 0.3,
    "weight": 2.9,
    "sprite": "/static/sprites/10.png"
  },
  {
    "id": 11,
    "dex": 11,
    "name": "#011 Metapod",
    "types": ["bug"],
    "height": 0.7,
    "weight": 9.9,
    "sprite": "/static/sprites/11.png"
  },
  {
    "id": 12,
    "dex": 12,
    "name": "#012 Butterfree",
    "types": ["bug", "flying"],
    "height": 1.1,
    "weight": 32.0,
    "sprite": "/static/sprites/12.png"
  },
  {
    "id": 13,
    "dex": 13,
    "name": "#013 Weedle",
    "types": ["bug", "poison"],
    "height": 0.3,
    "weight": 3.2,
    "sprite": "/static/sprites/13.png"
  },
  {
    "id": 14,
    "dex": 14,
    "name": "#014 Kakuna",
    "types": ["bug", "poison"],
    "height": 0.6,
    "weight": 10.0,
    "sprite": "/static/sprites/14.png"
  },
  {
    "id": 15,
    "dex": 15,
    "name": "#015 Beedrill",
    "types": ["bug", "poison"],
    "height": 1.0,
    "weight": 29.5,
    "sprite": "/static/sprites/15.png"
  },
  {
    "id": 15_01,
    "dex": 15,
    "name": "#015 Beedrill Mega",
    "types": ["bug", "poison"],
    "height": 1.4,
    "weight": 40.5,
    "sprite": "/static/sprites/15-mega.png"
  },
  {
    "id": 16,
    "dex": 16,
    "name": "#016 Pidgey",
    "types": ["normal", "flying"],
    "height": 0.3,
    "weight": 1.8,
    "sprite": "/static/sprites/16.png"
  },
  {
  "id": 17,
  "dex": 17,
  "name": "#017 Pidgeotto",
  "types": ["normal", "flying"],
  "height": 1.1,
  "weight": 30.0,
  "sprite": "/static/sprites/17.png"
},
{
  "id": 18,
  "dex": 18,
  "name": "#018 Pidgeot",
  "types": ["normal", "flying"],
  "height": 1.5,
  "weight": 39.5,
  "sprite": "/static/sprites/18.png"
},
{
  "id": 18_01,
  "dex": 18,
  "name": "#018 Pidgeot Mega",
  "types": ["normal", "flying"],
  "height": 2.2,
  "weight": 50.5,
  "sprite": "/static/sprites/18-mega.png"
},

{
  "id": 19,
  "dex": 19,
  "name": "#019 Rattata",
  "types": ["normal"],
  "height": 0.3,
  "weight": 3.5,
  "sprite": "/static/sprites/19.png"
},
{
  "id": 19_01,
  "dex": 19,
  "name": "#019 Rattata (Alola)",
  "types": ["dark", "normal"],
  "height": 0.3,
  "weight": 3.8,
  "sprite": "/static/sprites/19-alola.png"
},

{
  "id": 20,
  "dex": 20,
  "name": "#020 Raticate",
  "types": ["normal"],
  "height": 0.7,
  "weight": 18.5,
  "sprite": "/static/sprites/20.png"
},
{
  "id": 20_01,
  "dex": 20,
  "name": "#020 Raticate (Alola)",
  "types": ["dark", "normal"],
  "height": 0.7,
  "weight": 25.5,
  "sprite": "/static/sprites/20-alola.png"
},

{
  "id": 21,
  "dex": 21,
  "name": "#021 Spearow",
  "types": ["normal", "flying"],
  "height": 0.3,
  "weight": 2.0,
  "sprite": "/static/sprites/21.png"
},
{
  "id": 22,
  "dex": 22,
  "name": "#022 Fearow",
  "types": ["normal", "flying"],
  "height": 1.2,
  "weight": 38.0,
  "sprite": "/static/sprites/22.png"
},

{
  "id": 23,
  "dex": 23,
  "name": "#023 Ekans",
  "types": ["poison"],
  "height": 2.0,
  "weight": 6.9,
  "sprite": "/static/sprites/23.png"
},
{
  "id": 24,
  "dex": 24,
  "name": "#024 Arbok",
  "types": ["poison"],
  "height": 3.5,
  "weight": 65.0,
  "sprite": "/static/sprites/24.png"
},

{
  "id": 25,
  "dex": 25,
  "name": "#025 Pikachu",
  "types": ["electric"],
  "height": 0.4,
  "weight": 6.0,
  "sprite": "/static/sprites/25.png"
},
{
  "id": 25_01,
  "dex": 25,
  "name": "#025 Pikachu Gigantamax",
  "types": ["electric"],
  "height": 21.0,
  "weight": 0,
  "sprite": "/static/sprites/25-gmax.png"
},

{
  "id": 26,
  "dex": 26,
  "name": "#026 Raichu",
  "types": ["electric"],
  "height": 0.8,
  "weight": 30.0,
  "sprite": "/static/sprites/26.png"
},
{
  "id": 26_01,
  "dex": 26,
  "name": "#026 Raichu (Alola)",
  "types": ["electric", "psychic"],
  "height": 0.7,
  "weight": 21.0,
  "sprite": "/static/sprites/26-alola.png"
},

{
  "id": 27,
  "dex": 27,
  "name": "#027 Sandshrew",
  "types": ["ground"],
  "height": 0.6,
  "weight": 12.0,
  "sprite": "/static/sprites/27.png"
},
{
  "id": 27_01,
  "dex": 27,
  "name": "#027 Sandshrew (Alola)",
  "types": ["ice", "steel"],
  "height": 0.7,
  "weight": 40.0,
  "sprite": "/static/sprites/27-alola.png"
},

{
  "id": 28,
  "dex": 28,
  "name": "#028 Sandslash",
  "types": ["ground"],
  "height": 1.0,
  "weight": 29.5,
  "sprite": "/static/sprites/28.png"
},
{
  "id": 28_01,
  "dex": 28,
  "name": "#028 Sandslash (Alola)",
  "types": ["ice", "steel"],
  "height": 1.2,
  "weight": 55.0,
  "sprite": "/static/sprites/28-alola.png"
},

{
  "id": 29,
  "dex": 29,
  "name": "#029 Nidoran♀",
  "types": ["poison"],
  "height": 0.4,
  "weight": 7.0,
  "sprite": "/static/sprites/29.png"
},
{
  "id": 30,
  "dex": 30,
  "name": "#030 Nidorina",
  "types": ["poison"],
  "height": 0.8,
  "weight": 20.0,
  "sprite": "/static/sprites/30.png"
},
{
  "id": 31,
  "dex": 31,
  "name": "#031 Nidoqueen",
  "types": ["poison", "ground"],
  "height": 1.3,
  "weight": 60.0,
  "sprite": "/static/sprites/31.png"
},

{
  "id": 32,
  "dex": 32,
  "name": "#032 Nidoran♂",
  "types": ["poison"],
  "height": 0.5,
  "weight": 9.0,
  "sprite": "/static/sprites/32.png"
},
{
  "id": 33,
  "dex": 33,
  "name": "#033 Nidorino",
  "types": ["poison"],
  "height": 0.9,
  "weight": 19.5,
  "sprite": "/static/sprites/33.png"
},
{
  "id": 34,
  "dex": 34,
  "name": "#034 Nidoking",
  "types": ["poison", "ground"],
  "height": 1.4,
  "weight": 62.0,
  "sprite": "/static/sprites/34.png"
},

{
  "id": 35,
  "dex": 35,
  "name": "#035 Clefairy",
  "types": ["fairy"],
  "height": 0.6,
  "weight": 7.5,
  "sprite": "/static/sprites/35.png"
},
{
  "id": 36,
  "dex": 36,
  "name": "#036 Clefable",
  "types": ["fairy"],
  "height": 1.3,
  "weight": 40.0,
  "sprite": "/static/sprites/36.png"
},

{
  "id": 37,
  "dex": 37,
  "name": "#037 Vulpix",
  "types": ["fire"],
  "height": 0.6,
  "weight": 9.9,
  "sprite": "/static/sprites/37.png"
},
{
  "id": 37_01,
  "dex": 37,
  "name": "#037 Vulpix (Alola)",
  "types": ["ice"],
  "height": 0.6,
  "weight": 9.9,
  "sprite": "/static/sprites/37-alola.png"
},

{
  "id": 38,
  "dex": 38,
  "name": "#038 Ninetales",
  "types": ["fire"],
  "height": 1.1,
  "weight": 19.9,
  "sprite": "/static/sprites/38.png"
},
{
  "id": 38_01,
  "dex": 38,
  "name": "#038 Ninetales (Alola)",
  "types": ["ice", "fairy"],
  "height": 1.1,
  "weight": 19.9,
  "sprite": "/static/sprites/38-alola.png"
},

{
  "id": 39,
  "dex": 39,
  "name": "#039 Jigglypuff",
  "types": ["normal", "fairy"],
  "height": 0.5,
  "weight": 5.5,
  "sprite": "/static/sprites/39.png"
},
{
  "id": 40,
  "dex": 40,
  "name": "#040 Wigglytuff",
  "types": ["normal", "fairy"],
  "height": 1.0,
  "weight": 12.0,
  "sprite": "/static/sprites/40.png"
},

{
  "id": 41,
  "dex": 41,
  "name": "#041 Zubat",
  "types": ["poison", "flying"],
  "height": 0.8,
  "weight": 7.5,
  "sprite": "/static/sprites/41.png"
},
{
  "id": 42,
  "dex": 42,
  "name": "#042 Golbat",
  "types": ["poison", "flying"],
  "height": 1.6,
  "weight": 55.0,
  "sprite": "/static/sprites/42.png"
},

{
  "id": 43,
  "dex": 43,
  "name": "#043 Oddish",
  "types": ["grass", "poison"],
  "height": 0.5,
  "weight": 5.4,
  "sprite": "/static/sprites/43.png"
},
{
  "id": 44,
  "dex": 44,
  "name": "#044 Gloom",
  "types": ["grass", "poison"],
  "height": 0.8,
  "weight": 8.6,
  "sprite": "/static/sprites/44.png"
},
{
  "id": 45,
  "dex": 45,
  "name": "#045 Vileplume",
  "types": ["grass", "poison"],
  "height": 1.2,
  "weight": 18.6,
  "sprite": "/static/sprites/45.png"
},

{
  "id": 46,
  "dex": 46,
  "name": "#046 Paras",
  "types": ["bug", "grass"],
  "height": 0.3,
  "weight": 5.4,
  "sprite": "/static/sprites/46.png"
},
{
  "id": 47,
  "dex": 47,
  "name": "#047 Parasect",
  "types": ["bug", "grass"],
  "height": 1.0,
  "weight": 29.5,
  "sprite": "/static/sprites/47.png"
},

{
  "id": 48,
  "dex": 48,
  "name": "#048 Venonat",
  "types": ["bug", "poison"],
  "height": 1.0,
  "weight": 30.0,
  "sprite": "/static/sprites/48.png"
},
{
  "id": 49,
  "dex": 49,
  "name": "#049 Venomoth",
  "types": ["bug", "poison"],
  "height": 1.5,
  "weight": 12.5,
  "sprite": "/static/sprites/49.png"
},

{
  "id": 50,
  "dex": 50,
  "name": "#050 Diglett",
  "types": ["ground"],
  "height": 0.2,
  "weight": 0.8,
  "sprite": "/static/sprites/50.png"
},
{
  "id": 50_01,
  "dex": 50,
  "name": "#050 Diglett (Alola)",
  "types": ["ground", "steel"],
  "height": 0.2,
  "weight": 1.0,
  "sprite": "/static/sprites/50-alola.png"
},
  {
  "id": 51,
  "dex": 51,
  "name": "#051 Dugtrio",
  "types": ["ground"],
  "height": 0.7,
  "weight": 33.3,
  "sprite": "/static/sprites/51.png"
},
{
  "id": 51_01,
  "dex": 51,
  "name": "#051 Dugtrio (Forma de Alola)",
  "types": ["ground", "steel"],
  "height": 1.0,
  "weight": 66.6,
  "sprite": "/static/sprites/51-alola.png"
},

{
  "id": 52,
  "dex": 52,
  "name": "#052 Meowth",
  "types": ["normal"],
  "height": 0.4,
  "weight": 4.2,
  "sprite": "/static/sprites/52.png"
},
{
  "id": 52_01,
  "dex": 52,
  "name": "#052 Meowth (Alola)",
  "types": ["dark"],
  "height": 0.4,
  "weight": 4.2,
  "sprite": "/static/sprites/52-alola.png"
},
{
  "id": 52_02,
  "dex": 52,
  "name": "#052 Meowth (Galar)",
  "types": ["steel"],
  "height": 0.4,
  "weight": 7.5,
  "sprite": "/static/sprites/52-galar.png"
},

{
  "id": 53,
  "dex": 53,
  "name": "#053 Persian",
  "types": ["normal"],
  "height": 1.0,
  "weight": 32.0,
  "sprite": "/static/sprites/53.png"
},
{
  "id": 53_01,
  "dex": 53,
  "name": "#053 Persian (Alola)",
  "types": ["dark"],
  "height": 1.1,
  "weight": 33.0,
  "sprite": "/static/sprites/53-alola.png"
},

{
  "id": 54,
  "dex": 54,
  "name": "#054 Psyduck",
  "types": ["water"],
  "height": 0.8,
  "weight": 19.6,
  "sprite": "/static/sprites/54.png"
},
{
  "id": 55,
  "dex": 55,
  "name": "#055 Golduck",
  "types": ["water"],
  "height": 1.7,
  "weight": 76.6,
  "sprite": "/static/sprites/55.png"
},

{
  "id": 56,
  "dex": 56,
  "name": "#056 Mankey",
  "types": ["fighting"],
  "height": 0.5,
  "weight": 28.0,
  "sprite": "/static/sprites/56.png"
},
{
  "id": 57,
  "dex": 57,
  "name": "#057 Primeape",
  "types": ["fighting"],
  "height": 1.0,
  "weight": 32.0,
  "sprite": "/static/sprites/57.png"
},

{
  "id": 58,
  "dex": 58,
  "name": "#058 Growlithe",
  "types": ["fire"],
  "height": 0.7,
  "weight": 19.0,
  "sprite": "/static/sprites/58.png"
},
{
  "id": 58_01,
  "dex": 58,
  "name": "#058 Growlithe (Hisui)",
  "types": ["fire", "rock"],
  "height": 0.8,
  "weight": 22.7,
  "sprite": "/static/sprites/58-hisui.png"
},

{
  "id": 59,
  "dex": 59,
  "name": "#059 Arcanine",
  "types": ["fire"],
  "height": 1.9,
  "weight": 155.0,
  "sprite": "/static/sprites/59.png"
},
{
  "id": 59_01,
  "dex": 59,
  "name": "#059 Arcanine (Hisui)",
  "types": ["fire", "rock"],
  "height": 2.0,
  "weight": 168.0,
  "sprite": "/static/sprites/59-hisui.png"
},

{
  "id": 60,
  "dex": 60,
  "name": "#060 Poliwag",
  "types": ["water"],
  "height": 0.6,
  "weight": 12.4,
  "sprite": "/static/sprites/60.png"
},
{
  "id": 61,
  "dex": 61,
  "name": "#061 Poliwhirl",
  "types": ["water"],
  "height": 1.0,
  "weight": 20.0,
  "sprite": "/static/sprites/61.png"
},
{
  "id": 62,
  "dex": 62,
  "name": "#062 Poliwrath",
  "types": ["water", "fighting"],
  "height": 1.3,
  "weight": 54.0,
  "sprite": "/static/sprites/62.png"
},
{
  "id": 63,
  "dex": 63,
  "name": "#063 Abra",
  "types": ["psychic"],
  "height": 0.9,
  "weight": 19.5,
  "sprite": "/static/sprites/63.png"
},
{
  "id": 64,
  "dex": 64,
  "name": "#064 Kadabra",
  "types": ["psychic"],
  "height": 1.3,
  "weight": 56.5,
  "sprite": "/static/sprites/64.png"
},
{
  "id": 65,
  "dex": 65,
  "name": "#065 Alakazam",
  "types": ["psychic"],
  "height": 1.5,
  "weight": 48.0,
  "sprite": "/static/sprites/65.png"
},
{
  "id": 65_01,
  "dex": 65,
  "name": "#065 Alakazam Mega",
  "types": ["psychic"],
  "height": 1.2,
  "weight": 48.0,
  "sprite": "/static/sprites/65-mega.png"
},

{
  "id": 66,
  "dex": 66,
  "name": "#066 Machop",
  "types": ["fighting"],
  "height": 0.8,
  "weight": 19.5,
  "sprite": "/static/sprites/66.png"
},
{
  "id": 51,
  "dex": 51,
  "name": "#051 Dugtrio",
  "types": ["ground"],
  "height": 0.7,
  "weight": 33.3,
  "sprite": "/static/sprites/51.png"
},
{
  "id": 51_01,
  "dex": 51,
  "name": "#051 Dugtrio (Forma de Alola)",
  "types": ["ground", "steel"],
  "height": 1.0,
  "weight": 66.6,
  "sprite": "/static/sprites/51-alola.png"
},

{
  "id": 52,
  "dex": 52,
  "name": "#052 Meowth",
  "types": ["normal"],
  "height": 0.4,
  "weight": 4.2,
  "sprite": "/static/sprites/52.png"
},
{
  "id": 52_01,
  "dex": 52,
  "name": "#052 Meowth (Alola)",
  "types": ["dark"],
  "height": 0.4,
  "weight": 4.2,
  "sprite": "/static/sprites/52-alola.png"
},
{
  "id": 52_02,
  "dex": 52,
  "name": "#052 Meowth (Galar)",
  "types": ["steel"],
  "height": 0.4,
  "weight": 7.5,
  "sprite": "/static/sprites/52-galar.png"
},

{
  "id": 53,
  "dex": 53,
  "name": "#053 Persian",
  "types": ["normal"],
  "height": 1.0,
  "weight": 32.0,
  "sprite": "/static/sprites/53.png"
},
{
  "id": 53_01,
  "dex": 53,
  "name": "#053 Persian (Alola)",
  "types": ["dark"],
  "height": 1.1,
  "weight": 33.0,
  "sprite": "/static/sprites/53-alola.png"
},

{
  "id": 54,
  "dex": 54,
  "name": "#054 Psyduck",
  "types": ["water"],
  "height": 0.8,
  "weight": 19.6,
  "sprite": "/static/sprites/54.png"
},
{
  "id": 55,
  "dex": 55,
  "name": "#055 Golduck",
  "types": ["water"],
  "height": 1.7,
  "weight": 76.6,
  "sprite": "/static/sprites/55.png"
},

{
  "id": 56,
  "dex": 56,
  "name": "#056 Mankey",
  "types": ["fighting"],
  "height": 0.5,
  "weight": 28.0,
  "sprite": "/static/sprites/56.png"
},
{
  "id": 57,
  "dex": 57,
  "name": "#057 Primeape",
  "types": ["fighting"],
  "height": 1.0,
  "weight": 32.0,
  "sprite": "/static/sprites/57.png"
},

{
  "id": 58,
  "dex": 58,
  "name": "#058 Growlithe",
  "types": ["fire"],
  "height": 0.7,
  "weight": 19.0,
  "sprite": "/static/sprites/58.png"
},
{
  "id": 58_01,
  "dex": 58,
  "name": "#058 Growlithe (Hisui)",
  "types": ["fire", "rock"],
  "height": 0.8,
  "weight": 22.7,
  "sprite": "/static/sprites/58-hisui.png"
},

{
  "id": 59,
  "dex": 59,
  "name": "#059 Arcanine",
  "types": ["fire"],
  "height": 1.9,
  "weight": 155.0,
  "sprite": "/static/sprites/59.png"
},
{
  "id": 59_01,
  "dex": 59,
  "name": "#059 Arcanine (Hisui)",
  "types": ["fire", "rock"],
  "height": 2.0,
  "weight": 168.0,
  "sprite": "/static/sprites/59-hisui.png"
},

{
  "id": 60,
  "dex": 60,
  "name": "#060 Poliwag",
  "types": ["water"],
  "height": 0.6,
  "weight": 12.4,
  "sprite": "/static/sprites/60.png"
},
{
  "id": 61,
  "dex": 61,
  "name": "#061 Poliwhirl",
  "types": ["water"],
  "height": 1.0,
  "weight": 20.0,
  "sprite": "/static/sprites/61.png"
},
{
  "id": 62,
  "dex": 62,
  "name": "#062 Poliwrath",
  "types": ["water", "fighting"],
  "height": 1.3,
  "weight": 54.0,
  "sprite": "/static/sprites/62.png"
},
{
  "id": 63,
  "dex": 63,
  "name": "#063 Abra",
  "types": ["psychic"],
  "height": 0.9,
  "weight": 19.5,
  "sprite": "/static/sprites/63.png"
},
{
  "id": 64,
  "dex": 64,
  "name": "#064 Kadabra",
  "types": ["psychic"],
  "height": 1.3,
  "weight": 56.5,
  "sprite": "/static/sprites/64.png"
},
{
  "id": 65,
  "dex": 65,
  "name": "#065 Alakazam",
  "types": ["psychic"],
  "height": 1.5,
  "weight": 48.0,
  "sprite": "/static/sprites/65.png"
},
{
  "id": 65_01,
  "dex": 65,
  "name": "#065 Alakazam Mega",
  "types": ["psychic"],
  "height": 1.2,
  "weight": 48.0,
  "sprite": "/static/sprites/65-mega.png"
},

{
  "id": 66,
  "dex": 66,
  "name": "#066 Machop",
  "types": ["fighting"],
  "height": 0.8,
  "weight": 19.5,
  "sprite": "/static/sprites/66.png"
},
{
  "id": 67,
  "dex": 67,
  "name": "#067 Machoke",
  "types": ["fighting"],
  "height": 1.5,
  "weight": 70.5,
  "sprite": "/static/sprites/67.png"
},
{
  "id": 68,
  "dex": 68,
  "name": "#068 Machamp",
  "types": ["fighting"],
  "height": 1.6,
  "weight": 130.0,
  "sprite": "/static/sprites/68.png"
},
{
  "id": 68_01,
  "dex": 68,
  "name": "#068 Machamp Gigantamax",
  "types": ["fighting"],
  "height": 25.0,
  "weight": 0,
  "sprite": "/static/sprites/68-gmax.png"
},

{
  "id": 69,
  "dex": 69,
  "name": "#069 Bellsprout",
  "types": ["grass", "poison"],
  "height": 0.7,
  "weight": 4.0,
  "sprite": "/static/sprites/69.png"
},
{
  "id": 70,
  "dex": 70,
  "name": "#070 Weepinbell",
  "types": ["grass", "poison"],
  "height": 1.0,
  "weight": 6.4,
  "sprite": "/static/sprites/70.png"
},
{
  "id": 71,
  "dex": 71,
  "name": "#071 Victreebel",
  "types": ["grass", "poison"],
  "height": 1.7,
  "weight": 15.5,
  "sprite": "/static/sprites/71.png"
},

{
  "id": 72,
  "dex": 72,
  "name": "#072 Tentacool",
  "types": ["water", "poison"],
  "height": 0.9,
  "weight": 45.5,
  "sprite": "/static/sprites/72.png"
},
{
  "id": 73,
  "dex": 73,
  "name": "#073 Tentacruel",
  "types": ["water", "poison"],
  "height": 1.6,
  "weight": 55.0,
  "sprite": "/static/sprites/73.png"
},

{
  "id": 74,
  "dex": 74,
  "name": "#074 Geodude",
  "types": ["rock", "ground"],
  "height": 0.4,
  "weight": 20.0,
  "sprite": "/static/sprites/74.png"
},
{
  "id": 74_01,
  "dex": 74,
  "name": "#074 Geodude (Alola)",
  "types": ["rock", "electric"],
  "height": 0.4,
  "weight": 20.0,
  "sprite": "/static/sprites/74-alola.png"
},

{
  "id": 75,
  "dex": 75,
  "name": "#075 Graveler",
  "types": ["rock", "ground"],
  "height": 1.0,
  "weight": 105.0,
  "sprite": "/static/sprites/75.png"
},
{
  "id": 75_01,
  "dex": 75,
  "name": "#075 Graveler (Alola)",
  "types": ["rock", "electric"],
  "height": 1.0,
  "weight": 110.0,
  "sprite": "/static/sprites/75-alola.png"
},

{
  "id": 76,
  "dex": 76,
  "name": "#076 Golem",
  "types": ["rock", "ground"],
  "height": 1.4,
  "weight": 300.0,
  "sprite": "/static/sprites/76.png"
},
{
  "id": 76_01,
  "dex": 76,
  "name": "#076 Golem (Alola)",
  "types": ["rock", "electric"],
  "height": 1.7,
  "weight": 316.0,
  "sprite": "/static/sprites/76-alola.png"
},

{
  "id": 77,
  "dex": 77,
  "name": "#077 Ponyta",
  "types": ["fire"],
  "height": 1.0,
  "weight": 30.0,
  "sprite": "/static/sprites/77.png"
},
{
  "id": 77_01,
  "dex": 77,
  "name": "#077 Ponyta (Galar)",
  "types": ["psychic"],
  "height": 0.8,
  "weight": 24.0,
  "sprite": "/static/sprites/77-galar.png"
},

{
  "id": 78,
  "dex": 78,
  "name": "#078 Rapidash",
  "types": ["fire"],
  "height": 1.7,
  "weight": 95.0,
  "sprite": "/static/sprites/78.png"
},
{
  "id": 78_01,
  "dex": 78,
  "name": "#078 Rapidash (Galar)",
  "types": ["psychic", "fairy"],
  "height": 1.7,
  "weight": 80.0,
  "sprite": "/static/sprites/78-galar.png"
},

{
  "id": 79,
  "dex": 79,
  "name": "#079 Slowpoke",
  "types": ["water", "psychic"],
  "height": 1.2,
  "weight": 36.0,
  "sprite": "/static/sprites/79.png"
},
{
  "id": 79_01,
  "dex": 79,
  "name": "#079 Slowpoke (Galar)",
  "types": ["psychic"],
  "height": 1.2,
  "weight": 36.0,
  "sprite": "/static/sprites/79-galar.png"
},

{
  "id": 80,
  "dex": 80,
  "name": "#080 Slowbro",
  "types": ["water", "psychic"],
  "height": 1.6,
  "weight": 78.5,
  "sprite": "/static/sprites/80.png"
},
{
  "id": 80_01,
  "dex": 80,
  "name": "#080 Slowbro Mega",
  "types": ["water", "psychic"],
  "height": 2.0,
  "weight": 120.0,
  "sprite": "/static/sprites/80-mega.png"
},
{
  "id": 80_02,
  "dex": 80,
  "name": "#080 Slowbro (Galar)",
  "types": ["poison", "psychic"],
  "height": 1.6,
  "weight": 70.5,
  "sprite": "/static/sprites/80-galar.png"
},

{
  "id": 81,
  "dex": 81,
  "name": "#081 Magnemite",
  "types": ["electric", "steel"],
  "height": 0.3,
  "weight": 6.0,
  "sprite": "/static/sprites/81.png"
},
{
  "id": 82,
  "dex": 82,
  "name": "#082 Magneton",
  "types": ["electric", "steel"],
  "height": 1.0,
  "weight": 60.0,
  "sprite": "/static/sprites/82.png"
},
{
  "id": 83,
  "dex": 83,
  "name": "#083 Farfetch’d",
  "types": ["normal", "flying"],
  "height": 0.8,
  "weight": 15.0,
  "sprite": "/static/sprites/83.png"
},
{
  "id": 83_01,
  "dex": 83,
  "name": "#083 Farfetch’d (Galar)",
  "types": ["fighting"],
  "height": 0.8,
  "weight": 42.0,
  "sprite": "/static/sprites/83-galar.png"
},

{
  "id": 84,
  "dex": 84,
  "name": "#084 Doduo",
  "types": ["normal", "flying"],
  "height": 1.4,
  "weight": 39.2,
  "sprite": "/static/sprites/84.png"
},
{
  "id": 85,
  "dex": 85,
  "name": "#085 Dodrio",
  "types": ["normal", "flying"],
  "height": 1.8,
  "weight": 85.2,
  "sprite": "/static/sprites/85.png"
},

{
  "id": 86,
  "dex": 86,
  "name": "#086 Seel",
  "types": ["water"],
  "height": 1.1,
  "weight": 90.0,
  "sprite": "/static/sprites/86.png"
},
{
  "id": 87,
  "dex": 87,
  "name": "#087 Dewgong",
  "types": ["water", "ice"],
  "height": 1.7,
  "weight": 120.0,
  "sprite": "/static/sprites/87.png"
},

{
  "id": 88,
  "dex": 88,
  "name": "#088 Grimer",
  "types": ["poison"],
  "height": 0.9,
  "weight": 30.0,
  "sprite": "/static/sprites/88.png"
},
{
  "id": 88_01,
  "dex": 88,
  "name": "#088 Grimer (Alola)",
  "types": ["poison", "dark"],
  "height": 0.9,
  "weight": 42.0,
  "sprite": "/static/sprites/88-alola.png"
},

{
  "id": 89,
  "dex": 89,
  "name": "#089 Muk",
  "types": ["poison"],
  "height": 1.2,
  "weight": 30.0,
  "sprite": "/static/sprites/89.png"
},
{
  "id": 89_01,
  "dex": 89,
  "name": "#089 Muk (Alola)",
  "types": ["poison", "dark"],
  "height": 1.0,
  "weight": 52.0,
  "sprite": "/static/sprites/89-alola.png"
},

{
  "id": 90,
  "dex": 90,
  "name": "#090 Shellder",
  "types": ["water"],
  "height": 0.3,
  "weight": 4.0,
  "sprite": "/static/sprites/90.png"
},
{
  "id": 91,
  "dex": 91,
  "name": "#091 Cloyster",
  "types": ["water", "ice"],
  "height": 1.5,
  "weight": 132.5,
  "sprite": "/static/sprites/91.png"
},

{
  "id": 92,
  "dex": 92,
  "name": "#092 Gastly",
  "types": ["ghost", "poison"],
  "height": 1.3,
  "weight": 0.1,
  "sprite": "/static/sprites/92.png"
},
{
  "id": 93,
  "dex": 93,
  "name": "#093 Haunter",
  "types": ["ghost", "poison"],
  "height": 1.6,
  "weight": 0.1,
  "sprite": "/static/sprites/93.png"
},
{
  "id": 94,
  "dex": 94,
  "name": "#094 Gengar",
  "types": ["ghost", "poison"],
  "height": 1.5,
  "weight": 40.5,
  "sprite": "/static/sprites/94.png"
},
{
  "id": 94_01,
  "dex": 94,
  "name": "#094 Gengar Mega",
  "types": ["ghost", "poison"],
  "height": 1.4,
  "weight": 40.5,
  "sprite": "/static/sprites/94-mega.png"
},
{
  "id": 94_02,
  "dex": 94,
  "name": "#094 Gengar Gigantamax",
  "types": ["ghost", "poison"],
  "height": 20.0,
  "weight": 0,
  "sprite": "/static/sprites/94-gmax.png"
},

{
  "id": 95,
  "dex": 95,
  "name": "#095 Onix",
  "types": ["rock", "ground"],
  "height": 8.8,
  "weight": 210.0,
  "sprite": "/static/sprites/95.png"
},

{
  "id": 96,
  "dex": 96,
  "name": "#096 Drowzee",
  "types": ["psychic"],
  "height": 1.0,
  "weight": 32.4,
  "sprite": "/static/sprites/96.png"
},
{
  "id": 97,
  "dex": 97,
  "name": "#097 Hypno",
  "types": ["psychic"],
  "height": 1.6,
  "weight": 75.6,
  "sprite": "/static/sprites/97.png"
},

{
  "id": 98,
  "dex": 98,
  "name": "#098 Krabby",
  "types": ["water"],
  "height": 0.4,
  "weight": 6.5,
  "sprite": "/static/sprites/98.png"
},
{
  "id": 99,
  "dex": 99,
  "name": "#099 Kingler",
  "types": ["water"],
  "height": 1.3,
  "weight": 60.0,
  "sprite": "/static/sprites/99.png"
},
{
  "id": 99_01,
  "dex": 99,
  "name": "#099 Kingler Gigantamax",
  "types": ["water"],
  "height": 19.0,
  "weight": 0,
  "sprite": "/static/sprites/99-gmax.png"
},

{
  "id": 100,
  "dex": 100,
  "name": "#100 Voltorb",
  "types": ["electric"],
  "height": 0.5,
  "weight": 10.4,
  "sprite": "/static/sprites/100.png"
},
{
  "id": 100_01,
  "dex": 100,
  "name": "#100 Voltorb (Hisui)",
  "types": ["electric", "grass"],
  "height": 0.5,
  "weight": 13.0,
  "sprite": "/static/sprites/100-hisui.png"
},

{
  "id": 101,
  "dex": 101,
  "name": "#101 Electrode",
  "types": ["electric"],
  "height": 1.2,
  "weight": 66.6,
  "sprite": "/static/sprites/101.png"
},
{
  "id": 101_01,
  "dex": 101,
  "name": "#101 Electrode (Hisui)",
  "types": ["electric", "grass"],
  "height": 1.2,
  "weight": 71.0,
  "sprite": "/static/sprites/101-hisui.png"
},

{
  "id": 102,
  "dex": 102,
  "name": "#102 Exeggcute",
  "types": ["grass", "psychic"],
  "height": 0.4,
  "weight": 2.5,
  "sprite": "/static/sprites/102.png"
},
{
  "id": 103,
  "dex": 103,
  "name": "#103 Exeggutor",
  "types": ["grass", "psychic"],
  "height": 2.0,
  "weight": 120.0,
  "sprite": "/static/sprites/103.png"
},
{
  "id": 103_01,
  "dex": 103,
  "name": "#103 Exeggutor (Alola)",
  "types": ["grass", "dragon"],
  "height": 10.9,
  "weight": 415.0,
  "sprite": "/static/sprites/103-alola.png"
},

{
  "id": 104,
  "dex": 104,
  "name": "#104 Cubone",
  "types": ["ground"],
  "height": 0.4,
  "weight": 6.5,
  "sprite": "/static/sprites/104.png"
},
{
  "id": 105,
  "dex": 105,
  "name": "#105 Marowak",
  "types": ["ground"],
  "height": 1.0,
  "weight": 45.0,
  "sprite": "/static/sprites/105.png"
},
{
  "id": 105_01,
  "dex": 105,
  "name": "#105 Marowak (Alola)",
  "types": ["fire", "ghost"],
  "height": 1.0,
  "weight": 34.0,
  "sprite": "/static/sprites/105-alola.png"
},

{
  "id": 106,
  "dex": 106,
  "name": "#106 Hitmonlee",
  "types": ["fighting"],
  "height": 1.5,
  "weight": 49.8,
  "sprite": "/static/sprites/106.png"
},
{
  "id": 107,
  "dex": 107,
  "name": "#107 Hitmonchan",
  "types": ["fighting"],
  "height": 1.4,
  "weight": 50.2,
  "sprite": "/static/sprites/107.png"
},
{
  "id": 108,
  "dex": 108,
  "name": "#108 Lickitung",
  "types": ["normal"],
  "height": 1.2,
  "weight": 65.5,
  "sprite": "/static/sprites/108.png"
},

{
  "id": 109,
  "dex": 109,
  "name": "#109 Koffing",
  "types": ["poison"],
  "height": 0.6,
  "weight": 1.0,
  "sprite": "/static/sprites/109.png"
},
{
  "id": 110,
  "dex": 110,
  "name": "#110 Weezing",
  "types": ["poison"],
  "height": 1.2,
  "weight": 9.5,
  "sprite": "/static/sprites/110.png"
},
{
  "id": 110_01,
  "dex": 110,
  "name": "#110 Weezing (Galar)",
  "types": ["poison", "fairy"],
  "height": 3.0,
  "weight": 16.0,
  "sprite": "/static/sprites/110-galar.png"
},

{
  "id": 111,
  "dex": 111,
  "name": "#111 Rhyhorn",
  "types": ["ground", "rock"],
  "height": 1.0,
  "weight": 115.0,
  "sprite": "/static/sprites/111.png"
},
{
  "id": 112,
  "dex": 112,
  "name": "#112 Rhydon",
  "types": ["ground", "rock"],
  "height": 1.9,
  "weight": 120.0,
  "sprite": "/static/sprites/112.png"
},

{
  "id": 113,
  "dex": 113,
  "name": "#113 Chansey",
  "types": ["normal"],
  "height": 1.1,
  "weight": 34.6,
  "sprite": "/static/sprites/113.png"
},
{
  "id": 114,
  "dex": 114,
  "name": "#114 Tangela",
  "types": ["grass"],
  "height": 1.0,
  "weight": 35.0,
  "sprite": "/static/sprites/114.png"
},

{
  "id": 115,
  "dex": 115,
  "name": "#115 Kangaskhan",
  "types": ["normal"],
  "height": 2.2,
  "weight": 80.0,
  "sprite": "/static/sprites/115.png"
},
{
  "id": 115_01,
  "dex": 115,
  "name": "#115 Kangaskhan Mega",
  "types": ["normal"],
  "height": 2.2,
  "weight": 100.0,
  "sprite": "/static/sprites/115-mega.png"
},

{
  "id": 116,
  "dex": 116,
  "name": "#116 Horsea",
  "types": ["water"],
  "height": 0.4,
  "weight": 8.0,
  "sprite": "/static/sprites/116.png"
},
{
  "id": 117,
  "dex": 117,
  "name": "#117 Seadra",
  "types": ["water"],
  "height": 1.2,
  "weight": 25.0,
  "sprite": "/static/sprites/117.png"
},
{
  "id": 118,
  "dex": 118,
  "name": "#118 Goldeen",
  "types": ["water"],
  "height": 0.6,
  "weight": 15.0,
  "sprite": "/static/sprites/118.png"
},
{
  "id": 119,
  "dex": 119,
  "name": "#119 Seaking",
  "types": ["water"],
  "height": 1.3,
  "weight": 39.0,
  "sprite": "/static/sprites/119.png"
},

{
  "id": 120,
  "dex": 120,
  "name": "#120 Staryu",
  "types": ["water"],
  "height": 0.8,
  "weight": 34.5,
  "sprite": "/static/sprites/120.png"
},
{
  "id": 121,
  "dex": 121,
  "name": "#121 Starmie",
  "types": ["water", "psychic"],
  "height": 1.1,
  "weight": 80.0,
  "sprite": "/static/sprites/121.png"
},

{
  "id": 122,
  "dex": 122,
  "name": "#122 Mr. Mime",
  "types": ["psychic", "fairy"],
  "height": 1.3,
  "weight": 54.5,
  "sprite": "/static/sprites/122.png"
},
{
  "id": 122_01,
  "dex": 122,
  "name": "#122 Mr. Mime (Galar)",
  "types": ["ice", "psychic"],
  "height": 1.4,
  "weight": 56.8,
  "sprite": "/static/sprites/122-galar.png"
},

{
  "id": 123,
  "dex": 123,
  "name": "#123 Scyther",
  "types": ["bug", "flying"],
  "height": 1.5,
  "weight": 56.0,
  "sprite": "/static/sprites/123.png"
},

{
  "id": 124,
  "dex": 124,
  "name": "#124 Jynx",
  "types": ["ice", "psychic"],
  "height": 1.4,
  "weight": 40.6,
  "sprite": "/static/sprites/124.png"
},

{
  "id": 125,
  "dex": 125,
  "name": "#125 Electabuzz",
  "types": ["electric"],
  "height": 1.1,
  "weight": 30.0,
  "sprite": "/static/sprites/125.png"
},

{
  "id": 126,
  "dex": 126,
  "name": "#126 Magmar",
  "types": ["fire"],
  "height": 1.3,
  "weight": 44.5,
  "sprite": "/static/sprites/126.png"
},

{
  "id": 127,
  "dex": 127,
  "name": "#127 Pinsir",
  "types": ["bug"],
  "height": 1.5,
  "weight": 55.0,
  "sprite": "/static/sprites/127.png"
},
{
  "id": 127_01,
  "dex": 127,
  "name": "#127 Pinsir Mega",
  "types": ["bug", "flying"],
  "height": 1.7,
  "weight": 59.0,
  "sprite": "/static/sprites/127-mega.png"
},

{
  "id": 128,
  "dex": 128,
  "name": "#128 Tauros",
  "types": ["normal"],
  "height": 1.4,
  "weight": 88.4,
  "sprite": "/static/sprites/128.png"
},
{
  "id": 128_01,
  "dex": 128,
  "name": "#128 Tauros (Paldea Combat)",
  "types": ["fighting"],
  "height": 1.4,
  "weight": 88.4,
  "sprite": "/static/sprites/128-paldea-combat.png"
},
{
  "id": 128_02,
  "dex": 128,
  "name": "#128 Tauros (Paldea Blaze)",
  "types": ["fighting", "fire"],
  "height": 1.4,
  "weight": 88.4,
  "sprite": "/static/sprites/128-paldea-blaze.png"
},
{
  "id": 128_03,
  "dex": 128,
  "name": "#128 Tauros (Paldea Aqua)",
  "types": ["fighting", "water"],
  "height": 1.4,
  "weight": 88.4,
  "sprite": "/static/sprites/128-paldea-aqua.png"
},

{
  "id": 129,
  "dex": 129,
  "name": "#129 Magikarp",
  "types": ["water"],
  "height": 0.9,
  "weight": 10.0,
  "sprite": "/static/sprites/129.png"
},

{
  "id": 130,
  "dex": 130,
  "name": "#130 Gyarados",
  "types": ["water", "flying"],
  "height": 6.5,
  "weight": 235.0,
  "sprite": "/static/sprites/130.png"
},
{
  "id": 130_01,
  "dex": 130,
  "name": "#130 Gyarados Mega",
  "types": ["water", "dark"],
  "height": 6.5,
  "weight": 305.0,
  "sprite": "/static/sprites/130-mega.png"
},

{
  "id": 131,
  "dex": 131,
  "name": "#131 Lapras",
  "types": ["water", "ice"],
  "height": 2.5,
  "weight": 220.0,
  "sprite": "/static/sprites/131.png"
},
{
  "id": 131_01,
  "dex": 131,
  "name": "#131 Lapras Gigantamax",
  "types": ["water", "ice"],
  "height": 24.0,
  "weight": 0,
  "sprite": "/static/sprites/131-gmax.png"
},

{
  "id": 132,
  "dex": 132,
  "name": "#132 Ditto",
  "types": ["normal"],
  "height": 0.3,
  "weight": 4.0,
  "sprite": "/static/sprites/132.png"
},

{
  "id": 133,
  "dex": 133,
  "name": "#133 Eevee",
  "types": ["normal"],
  "height": 0.3,
  "weight": 6.5,
  "sprite": "/static/sprites/133.png"
},
{
  "id": 133_01,
  "dex": 133,
  "name": "#133 Eevee Gigantamax",
  "types": ["normal"],
  "height": 18.0,
  "weight": 0,
  "sprite": "/static/sprites/133-gmax.png"
},

{
  "id": 134,
  "dex": 134,
  "name": "#134 Vaporeon",
  "types": ["water"],
  "height": 1.0,
  "weight": 29.0,
  "sprite": "/static/sprites/134.png"
},

{
  "id": 135,
  "dex": 135,
  "name": "#135 Jolteon",
  "types": ["electric"],
  "height": 0.8,
  "weight": 24.5,
  "sprite": "/static/sprites/135.png"
},

{
  "id": 136,
  "dex": 136,
  "name": "#136 Flareon",
  "types": ["fire"],
  "height": 0.9,
  "weight": 25.0,
  "sprite": "/static/sprites/136.png"
},

{
  "id": 137,
  "dex": 137,
  "name": "#137 Porygon",
  "types": ["normal"],
  "height": 0.8,
  "weight": 36.5,
  "sprite": "/static/sprites/137.png"
},

{
  "id": 138,
  "dex": 138,
  "name": "#138 Omanyte",
  "types": ["rock", "water"],
  "height": 0.4,
  "weight": 7.5,
  "sprite": "/static/sprites/138.png"
},
{
  "id": 139,
  "dex": 139,
  "name": "#139 Omastar",
  "types": ["rock", "water"],
  "height": 1.0,
  "weight": 35.0,
  "sprite": "/static/sprites/139.png"
},

{
  "id": 140,
  "dex": 140,
  "name": "#140 Kabuto",
  "types": ["rock", "water"],
  "height": 0.5,
  "weight": 11.5,
  "sprite": "/static/sprites/140.png"
},
{
  "id": 141,
  "dex": 141,
  "name": "#141 Kabutops",
  "types": ["rock", "water"],
  "height": 1.3,
  "weight": 40.5,
  "sprite": "/static/sprites/141.png"
},

{
  "id": 142,
  "dex": 142,
  "name": "#142 Aerodactyl",
  "types": ["rock", "flying"],
  "height": 1.8,
  "weight": 59.0,
  "sprite": "/static/sprites/142.png"
},
{
  "id": 142_01,
  "dex": 142,
  "name": "#142 Aerodactyl Mega",
  "types": ["rock", "flying"],
  "height": 2.1,
  "weight": 79.0,
  "sprite": "/static/sprites/142-mega.png"
},

{
  "id": 143,
  "dex": 143,
  "name": "#143 Snorlax",
  "types": ["normal"],
  "height": 2.1,
  "weight": 460.0,
  "sprite": "/static/sprites/143.png"
},
{
  "id": 143_01,
  "dex": 143,
  "name": "#143 Snorlax Gigantamax",
  "types": ["normal"],
  "height": 35.0,
  "weight": 0,
  "sprite": "/static/sprites/143-gmax.png"
},

{
  "id": 144,
  "dex": 144,
  "name": "#144 Articuno",
  "types": ["ice", "flying"],
  "height": 1.7,
  "weight": 55.4,
  "sprite": "/static/sprites/144.png"
},
{
  "id": 144_01,
  "dex": 144,
  "name": "#144 Articuno (Galar)",
  "types": ["psychic", "flying"],
  "height": 1.7,
  "weight": 50.9,
  "sprite": "/static/sprites/144-galar.png"
},

{
  "id": 145,
  "dex": 145,
  "name": "#145 Zapdos",
  "types": ["electric", "flying"],
  "height": 1.6,
  "weight": 52.6,
  "sprite": "/static/sprites/145.png"
},
{
  "id": 145_01,
  "dex": 145,
  "name": "#145 Zapdos (Galar)",
  "types": ["fighting", "flying"],
  "height": 1.6,
  "weight": 58.2,
  "sprite": "/static/sprites/145-galar.png"
},

{
  "id": 146,
  "dex": 146,
  "name": "#146 Moltres",
  "types": ["fire", "flying"],
  "height": 2.0,
  "weight": 60.0,
  "sprite": "/static/sprites/146.png"
},
{
  "id": 146_01,
  "dex": 146,
  "name": "#146 Moltres (Galar)",
  "types": ["dark", "flying"],
  "height": 2.0,
  "weight": 66.0,
  "sprite": "/static/sprites/146-galar.png"
},

{
  "id": 147,
  "dex": 147,
  "name": "#147 Dratini",
  "types": ["dragon"],
  "height": 1.8,
  "weight": 3.3,
  "sprite": "/static/sprites/147.png"
},
{
  "id": 148,
  "dex": 148,
  "name": "#148 Dragonair",
  "types": ["dragon"],
  "height": 4.0,
  "weight": 16.5,
  "sprite": "/static/sprites/148.png"
},
{
  "id": 149,
  "dex": 149,
  "name": "#149 Dragonite",
  "types": ["dragon", "flying"],
  "height": 2.2,
  "weight": 210.0,
  "sprite": "/static/sprites/149.png"
},

{
  "id": 150,
  "dex": 150,
  "name": "#150 Mewtwo",
  "types": ["psychic"],
  "height": 2.0,
  "weight": 122.0,
  "sprite": "/static/sprites/150.png"
},
{
  "id": 150_01,
  "dex": 150,
  "name": "#150 Mewtwo Mega X",
  "types": ["psychic", "fighting"],
  "height": 2.3,
  "weight": 127.0,
  "sprite": "/static/sprites/150-mega-x.png"
},
{
  "id": 150_02,
  "dex": 150,
  "name": "#150 Mewtwo Mega Y",
  "types": ["psychic"],
  "height": 1.5,
  "weight": 33.0,
  "sprite": "/static/sprites/150-mega-y.png"
},

{
  "id": 151,
  "dex": 151,
  "name": "#151 Mew",
  "types": ["psychic"],
  "height": 0.4,
  "weight": 4.0,
  "sprite": "/static/sprites/151.png"
},
{
  "id": 152,
  "dex": 152,
  "name": "#152 Chikorita",
  "types": ["grass"],
  "height": 0.9,
  "weight": 6.4,
  "sprite": "/static/sprites/152.png"
},

{
  "id": 153,
  "dex": 153,
  "name": "#153 Bayleef",
  "types": ["grass"],
  "height": 1.2,
  "weight": 15.8,
  "sprite": "/static/sprites/153.png"
},

{
  "id": 154,
  "dex": 154,
  "name": "#154 Meganium",
  "types": ["grass"],
  "height": 1.8,
  "weight": 100.5,
  "sprite": "/static/sprites/154.png"
},

{
  "id": 155,
  "dex": 155,
  "name": "#155 Cyndaquil",
  "types": ["fire"],
  "height": 0.5,
  "weight": 7.9,
  "sprite": "/static/sprites/155.png"
},

{
  "id": 156,
  "dex": 156,
  "name": "#156 Quilava",
  "types": ["fire"],
  "height": 0.9,
  "weight": 19.0,
  "sprite": "/static/sprites/156.png"
},

{
  "id": 157,
  "dex": 157,
  "name": "#157 Typhlosion",
  "types": ["fire"],
  "height": 1.7,
  "weight": 79.5,
  "sprite": "/static/sprites/157.png"
},
{
  "id": 157_01,
  "dex": 157,
  "name": "#157 Typhlosion (Hisui)",
  "types": ["fire", "ghost"],
  "height": 1.6,
  "weight": 69.8,
  "sprite": "/static/sprites/157-hisui.png"
},

{
  "id": 158,
  "dex": 158,
  "name": "#158 Totodile",
  "types": ["water"],
  "height": 0.6,
  "weight": 9.5,
  "sprite": "/static/sprites/158.png"
},

{
  "id": 159,
  "dex": 159,
  "name": "#159 Croconaw",
  "types": ["water"],
  "height": 1.1,
  "weight": 25.0,
  "sprite": "/static/sprites/159.png"
},

{
  "id": 160,
  "dex": 160,
  "name": "#160 Feraligatr",
  "types": ["water"],
  "height": 2.3,
  "weight": 88.8,
  "sprite": "/static/sprites/160.png"
},

{
  "id": 161,
  "dex": 161,
  "name": "#161 Sentret",
  "types": ["normal"],
  "height": 0.8,
  "weight": 6.0,
  "sprite": "/static/sprites/161.png"
},

{
  "id": 162,
  "dex": 162,
  "name": "#162 Furret",
  "types": ["normal"],
  "height": 1.8,
  "weight": 32.5,
  "sprite": "/static/sprites/162.png"
},

{
  "id": 163,
  "dex": 163,
  "name": "#163 Hoothoot",
  "types": ["normal", "flying"],
  "height": 0.7,
  "weight": 21.2,
  "sprite": "/static/sprites/163.png"
},

{
  "id": 164,
  "dex": 164,
  "name": "#164 Noctowl",
  "types": ["normal", "flying"],
  "height": 1.6,
  "weight": 40.8,
  "sprite": "/static/sprites/164.png"
},

{
  "id": 165,
  "dex": 165,
  "name": "#165 Ledyba",
  "types": ["bug", "flying"],
  "height": 1.0,
  "weight": 10.8,
  "sprite": "/static/sprites/165.png"
},

{
  "id": 166,
  "dex": 166,
  "name": "#166 Ledian",
  "types": ["bug", "flying"],
  "height": 1.4,
  "weight": 35.6,
  "sprite": "/static/sprites/166.png"
},

{
  "id": 167,
  "dex": 167,
  "name": "#167 Spinarak",
  "types": ["bug", "poison"],
  "height": 0.5,
  "weight": 8.5,
  "sprite": "/static/sprites/167.png"
},

{
  "id": 168,
  "dex": 168,
  "name": "#168 Ariados",
  "types": ["bug", "poison"],
  "height": 1.1,
  "weight": 33.5,
  "sprite": "/static/sprites/168.png"
},

{
  "id": 169,
  "dex": 169,
  "name": "#169 Crobat",
  "types": ["poison", "flying"],
  "height": 1.8,
  "weight": 75.0,
  "sprite": "/static/sprites/169.png"
},

{
  "id": 170,
  "dex": 170,
  "name": "#170 Chinchou",
  "types": ["water", "electric"],
  "height": 0.5,
  "weight": 12.0,
  "sprite": "/static/sprites/170.png"
},

{
  "id": 171,
  "dex": 171,
  "name": "#171 Lanturn",
  "types": ["water", "electric"],
  "height": 1.2,
  "weight": 22.5,
  "sprite": "/static/sprites/171.png"
},

{
  "id": 172,
  "dex": 172,
  "name": "#172 Pichu",
  "types": ["electric"],
  "height": 0.3,
  "weight": 2.0,
  "sprite": "/static/sprites/172.png"
},

{
  "id": 173,
  "dex": 173,
  "name": "#173 Cleffa",
  "types": ["fairy"],
  "height": 0.3,
  "weight": 3.0,
  "sprite": "/static/sprites/173.png"
},

{
  "id": 174,
  "dex": 174,
  "name": "#174 Igglybuff",
  "types": ["normal", "fairy"],
  "height": 0.3,
  "weight": 1.0,
  "sprite": "/static/sprites/174.png"
},

{
  "id": 175,
  "dex": 175,
  "name": "#175 Togepi",
  "types": ["fairy"],
  "height": 0.3,
  "weight": 1.5,
  "sprite": "/static/sprites/175.png"
},

{
  "id": 176,
  "dex": 176,
  "name": "#176 Togetic",
  "types": ["fairy", "flying"],
  "height": 0.6,
  "weight": 3.2,
  "sprite": "/static/sprites/176.png"
},

{
  "id": 177,
  "dex": 177,
  "name": "#177 Natu",
  "types": ["psychic", "flying"],
  "height": 0.2,
  "weight": 2.0,
  "sprite": "/static/sprites/177.png"
},

{
  "id": 178,
  "dex": 178,
  "name": "#178 Xatu",
  "types": ["psychic", "flying"],
  "height": 1.5,
  "weight": 15.0,
  "sprite": "/static/sprites/178.png"
},

{
  "id": 179,
  "dex": 179,
  "name": "#179 Mareep",
  "types": ["electric"],
  "height": 0.6,
  "weight": 7.8,
  "sprite": "/static/sprites/179.png"
},

{
  "id": 180,
  "dex": 180,
  "name": "#180 Flaaffy",
  "types": ["electric"],
  "height": 0.8,
  "weight": 13.3,
  "sprite": "/static/sprites/180.png"
},

{
  "id": 181,
  "dex": 181,
  "name": "#181 Ampharos",
  "types": ["electric"],
  "height": 1.4,
  "weight": 61.5,
  "sprite": "/static/sprites/181.png"
},
{
  "id": 181_01,
  "dex": 181,
  "name": "#181 Ampharos Mega",
  "types": ["electric", "dragon"],
  "height": 1.4,
  "weight": 61.5,
  "sprite": "/static/sprites/181-mega.png"
},

{
  "id": 182,
  "dex": 182,
  "name": "#182 Bellossom",
  "types": ["grass"],
  "height": 0.4,
  "weight": 5.8,
  "sprite": "/static/sprites/182.png"
},

{
  "id": 183,
  "dex": 183,
  "name": "#183 Marill",
  "types": ["water", "fairy"],
  "height": 0.4,
  "weight": 8.5,
  "sprite": "/static/sprites/183.png"
},

{
  "id": 184,
  "dex": 184,
  "name": "#184 Azumarill",
  "types": ["water", "fairy"],
  "height": 0.8,
  "weight": 28.5,
  "sprite": "/static/sprites/184.png"
},

{
  "id": 185,
  "dex": 185,
  "name": "#185 Sudowoodo",
  "types": ["rock"],
  "height": 1.2,
  "weight": 38.0,
  "sprite": "/static/sprites/185.png"
},

{
  "id": 186,
  "dex": 186,
  "name": "#186 Politoed",
  "types": ["water"],
  "height": 1.1,
  "weight": 33.9,
  "sprite": "/static/sprites/186.png"
},

{
  "id": 187,
  "dex": 187,
  "name": "#187 Hoppip",
  "types": ["grass", "flying"],
  "height": 0.4,
  "weight": 0.5,
  "sprite": "/static/sprites/187.png"
},

{
  "id": 188,
  "dex": 188,
  "name": "#188 Skiploom",
  "types": ["grass", "flying"],
  "height": 0.6,
  "weight": 1.0,
  "sprite": "/static/sprites/188.png"
},

{
  "id": 189,
  "dex": 189,
  "name": "#189 Jumpluff",
  "types": ["grass", "flying"],
  "height": 0.8,
  "weight": 3.0,
  "sprite": "/static/sprites/189.png"
},

{
  "id": 190,
  "dex": 190,
  "name": "#190 Aipom",
  "types": ["normal"],
  "height": 0.8,
  "weight": 11.5,
  "sprite": "/static/sprites/190.png"
},

{
  "id": 191,
  "dex": 191,
  "name": "#191 Sunkern",
  "types": ["grass"],
  "height": 0.3,
  "weight": 1.8,
  "sprite": "/static/sprites/191.png"
},

{
  "id": 192,
  "dex": 192,
  "name": "#192 Sunflora",
  "types": ["grass"],
  "height": 0.8,
  "weight": 8.5,
  "sprite": "/static/sprites/192.png"
},

{
  "id": 193,
  "dex": 193,
  "name": "#193 Yanma",
  "types": ["bug", "flying"],
  "height": 1.2,
  "weight": 38.0,
  "sprite": "/static/sprites/193.png"
},

{
  "id": 194,
  "dex": 194,
  "name": "#194 Wooper",
  "types": ["water", "ground"],
  "height": 0.4,
  "weight": 8.5,
  "sprite": "/static/sprites/194.png"
},
{
  "id": 194_01,
  "dex": 194,
  "name": "#194 Wooper (Paldea)",
  "types": ["poison", "ground"],
  "height": 0.4,
  "weight": 11.0,
  "sprite": "/static/sprites/194-paldea.png"
},

{
  "id": 195,
  "dex": 195,
  "name": "#195 Quagsire",
  "types": ["water", "ground"],
  "height": 1.4,
  "weight": 75.0,
  "sprite": "/static/sprites/195.png"
},

{
  "id": 196,
  "dex": 196,
  "name": "#196 Espeon",
  "types": ["psychic"],
  "height": 0.9,
  "weight": 26.5,
  "sprite": "/static/sprites/196.png"
},

{
  "id": 197,
  "dex": 197,
  "name": "#197 Umbreon",
  "types": ["dark"],
  "height": 1.0,
  "weight": 27.0,
  "sprite": "/static/sprites/197.png"
},

{
  "id": 198,
  "dex": 198,
  "name": "#198 Murkrow",
  "types": ["dark", "flying"],
  "height": 0.5,
  "weight": 2.1,
  "sprite": "/static/sprites/198.png"
},

{
  "id": 199,
  "dex": 199,
  "name": "#199 Slowking",
  "types": ["water", "psychic"],
  "height": 2.0,
  "weight": 79.5,
  "sprite": "/static/sprites/199.png"
},
{
  "id": 199_01,
  "dex": 199,
  "name": "#199 Slowking (Galar)",
  "types": ["poison", "psychic"],
  "height": 1.8,
  "weight": 79.5,
  "sprite": "/static/sprites/199-galar.png"
},

{
  "id": 200,
  "dex": 200,
  "name": "#200 Misdreavus",
  "types": ["ghost"],
  "height": 0.7,
  "weight": 1.0,
  "sprite": "/static/sprites/200.png"
},
{
  "id": 251,
  "dex": 251,
  "name": "#251 Celebi",
  "types": ["psychic", "grass"],
  "height": 0.6,
  "weight": 5.0,
  "sprite": "/static/sprites/251.png"
},

{
  "id": 252,
  "dex": 252,
  "name": "#252 Treecko",
  "types": ["grass"],
  "height": 0.5,
  "weight": 5.0,
  "sprite": "/static/sprites/252.png"
},

{
  "id": 253,
  "dex": 253,
  "name": "#253 Grovyle",
  "types": ["grass"],
  "height": 0.9,
  "weight": 21.6,
  "sprite": "/static/sprites/253.png"
},

{
  "id": 254,
  "dex": 254,
  "name": "#254 Sceptile",
  "types": ["grass"],
  "height": 1.7,
  "weight": 52.2,
  "sprite": "/static/sprites/254.png"
},
{
  "id": 25401,
  "dex": 254,
  "name": "#254 Sceptile Mega",
  "types": ["grass", "dragon"],
  "height": 1.9,
  "weight": 55.2,
  "sprite": "/static/sprites/254-mega.png"
},

{
  "id": 255,
  "dex": 255,
  "name": "#255 Torchic",
  "types": ["fire"],
  "height": 0.4,
  "weight": 2.5,
  "sprite": "/static/sprites/255.png"
},

{
  "id": 256,
  "dex": 256,
  "name": "#256 Combusken",
  "types": ["fire", "fighting"],
  "height": 0.9,
  "weight": 19.5,
  "sprite": "/static/sprites/256.png"
},

{
  "id": 257,
  "dex": 257,
  "name": "#257 Blaziken",
  "types": ["fire", "fighting"],
  "height": 1.9,
  "weight": 52.0,
  "sprite": "/static/sprites/257.png"
},
{
  "id": 25701,
  "dex": 257,
  "name": "#257 Blaziken Mega",
  "types": ["fire", "fighting"],
  "height": 1.9,
  "weight": 52.0,
  "sprite": "/static/sprites/257-mega.png"
},

{
  "id": 258,
  "dex": 258,
  "name": "#258 Mudkip",
  "types": ["water"],
  "height": 0.4,
  "weight": 7.6,
  "sprite": "/static/sprites/258.png"
},

{
  "id": 259,
  "dex": 259,
  "name": "#259 Marshtomp",
  "types": ["water", "ground"],
  "height": 0.7,
  "weight": 28.0,
  "sprite": "/static/sprites/259.png"
},

{
  "id": 260,
  "dex": 260,
  "name": "#260 Swampert",
  "types": ["water", "ground"],
  "height": 1.5,
  "weight": 81.9,
  "sprite": "/static/sprites/260.png"
},
{
  "id": 26001,
  "dex": 260,
  "name": "#260 Swampert Mega",
  "types": ["water", "ground"],
  "height": 1.9,
  "weight": 102.0,
  "sprite": "/static/sprites/260-mega.png"
},

{
  "id": 261,
  "dex": 261,
  "name": "#261 Poochyena",
  "types": ["dark"],
  "height": 0.5,
  "weight": 13.6,
  "sprite": "/static/sprites/261.png"
},

{
  "id": 262,
  "dex": 262,
  "name": "#262 Mightyena",
  "types": ["dark"],
  "height": 1.0,
  "weight": 37.0,
  "sprite": "/static/sprites/262.png"
},

{
  "id": 263,
  "dex": 263,
  "name": "#263 Zigzagoon",
  "types": ["normal"],
  "height": 0.4,
  "weight": 17.5,
  "sprite": "/static/sprites/263.png"
},
{
  "id": 26301,
  "dex": 263,
  "name": "#263 Zigzagoon (Galar)",
  "types": ["dark", "normal"],
  "height": 0.4,
  "weight": 17.5,
  "sprite": "/static/sprites/263-galar.png"
},

{
  "id": 264,
  "dex": 264,
  "name": "#264 Linoone",
  "types": ["normal"],
  "height": 0.5,
  "weight": 32.5,
  "sprite": "/static/sprites/264.png"
},
{
  "id": 26401,
  "dex": 264,
  "name": "#264 Linoone (Galar)",
  "types": ["dark", "normal"],
  "height": 0.5,
  "weight": 32.5,
  "sprite": "/static/sprites/264-galar.png"
},

{
  "id": 265,
  "dex": 265,
  "name": "#265 Wurmple",
  "types": ["bug"],
  "height": 0.3,
  "weight": 3.6,
  "sprite": "/static/sprites/265.png"
},

{
  "id": 266,
  "dex": 266,
  "name": "#266 Silcoon",
  "types": ["bug"],
  "height": 0.6,
  "weight": 10.0,
  "sprite": "/static/sprites/266.png"
},

{
  "id": 267,
  "dex": 267,
  "name": "#267 Beautifly",
  "types": ["bug", "flying"],
  "height": 1.0,
  "weight": 28.4,
  "sprite": "/static/sprites/267.png"
},

{
  "id": 268,
  "dex": 268,
  "name": "#268 Cascoon",
  "types": ["bug"],
  "height": 0.7,
  "weight": 11.5,
  "sprite": "/static/sprites/268.png"
},

{
  "id": 269,
  "dex": 269,
  "name": "#269 Dustox",
  "types": ["bug", "poison"],
  "height": 1.2,
  "weight": 31.6,
  "sprite": "/static/sprites/269.png"
},

{
  "id": 270,
  "dex": 270,
  "name": "#270 Lotad",
  "types": ["water", "grass"],
  "height": 0.5,
  "weight": 2.6,
  "sprite": "/static/sprites/270.png"
},

{
  "id": 271,
  "dex": 271,
  "name": "#271 Lombre",
  "types": ["water", "grass"],
  "height": 1.2,
  "weight": 32.5,
  "sprite": "/static/sprites/271.png"
},

{
  "id": 272,
  "dex": 272,
  "name": "#272 Ludicolo",
  "types": ["water", "grass"],
  "height": 1.5,
  "weight": 55.0,
  "sprite": "/static/sprites/272.png"
},

{
  "id": 273,
  "dex": 273,
  "name": "#273 Seedot",
  "types": ["grass"],
  "height": 0.5,
  "weight": 4.0,
  "sprite": "/static/sprites/273.png"
},

{
  "id": 274,
  "dex": 274,
  "name": "#274 Nuzleaf",
  "types": ["grass", "dark"],
  "height": 1.0,
  "weight": 28.0,
  "sprite": "/static/sprites/274.png"
},

{
  "id": 275,
  "dex": 275,
  "name": "#275 Shiftry",
  "types": ["grass", "dark"],
  "height": 1.3,
  "weight": 59.6,
  "sprite": "/static/sprites/275.png"
},

{
  "id": 276,
  "dex": 276,
  "name": "#276 Taillow",
  "types": ["normal", "flying"],
  "height": 0.3,
  "weight": 2.3,
  "sprite": "/static/sprites/276.png"
},

{
  "id": 277,
  "dex": 277,
  "name": "#277 Swellow",
  "types": ["normal", "flying"],
  "height": 0.7,
  "weight": 19.8,
  "sprite": "/static/sprites/277.png"
},

{
  "id": 278,
  "dex": 278,
  "name": "#278 Wingull",
  "types": ["water", "flying"],
  "height": 0.6,
  "weight": 9.5,
  "sprite": "/static/sprites/278.png"
},

{
  "id": 279,
  "dex": 279,
  "name": "#279 Pelipper",
  "types": ["water", "flying"],
  "height": 1.2,
  "weight": 28.0,
  "sprite": "/static/sprites/279.png"
},

{
  "id": 280,
  "dex": 280,
  "name": "#280 Ralts",
  "types": ["psychic", "fairy"],
  "height": 0.4,
  "weight": 6.6,
  "sprite": "/static/sprites/280.png"
},

{
  "id": 281,
  "dex": 281,
  "name": "#281 Kirlia",
  "types": ["psychic", "fairy"],
  "height": 0.8,
  "weight": 20.2,
  "sprite": "/static/sprites/281.png"
},

{
  "id": 282,
  "dex": 282,
  "name": "#282 Gardevoir",
  "types": ["psychic", "fairy"],
  "height": 1.6,
  "weight": 48.4,
  "sprite": "/static/sprites/282.png"
},
{
  "id": 28201,
  "dex": 282,
  "name": "#282 Gardevoir Mega",
  "types": ["psychic", "fairy"],
  "height": 1.6,
  "weight": 48.4,
  "sprite": "/static/sprites/282-mega.png"
},

{
  "id": 283,
  "dex": 283,
  "name": "#283 Surskit",
  "types": ["bug", "water"],
  "height": 0.5,
  "weight": 1.7,
  "sprite": "/static/sprites/283.png"
},

{
  "id": 284,
  "dex": 284,
  "name": "#284 Masquerain",
  "types": ["bug", "flying"],
  "height": 0.8,
  "weight": 3.6,
  "sprite": "/static/sprites/284.png"
},

{
  "id": 285,
  "dex": 285,
  "name": "#285 Shroomish",
  "types": ["grass"],
  "height": 0.4,
  "weight": 4.5,
  "sprite": "/static/sprites/285.png"
},

{
  "id": 286,
  "dex": 286,
  "name": "#286 Breloom",
  "types": ["grass", "fighting"],
  "height": 1.2,
  "weight": 39.2,
  "sprite": "/static/sprites/286.png"
},

{
  "id": 287,
  "dex": 287,
  "name": "#287 Slakoth",
  "types": ["normal"],
  "height": 0.8,
  "weight": 24.0,
  "sprite": "/static/sprites/287.png"
},

{
  "id": 288,
  "dex": 288,
  "name": "#288 Vigoroth",
  "types": ["normal"],
  "height": 1.4,
  "weight": 46.5,
  "sprite": "/static/sprites/288.png"
},

{
  "id": 289,
  "dex": 289,
  "name": "#289 Slaking",
  "types": ["normal"],
  "height": 2.0,
  "weight": 130.5,
  "sprite": "/static/sprites/289.png"
},

{
  "id": 290,
  "dex": 290,
  "name": "#290 Nincada",
  "types": ["bug", "ground"],
  "height": 0.5,
  "weight": 5.5,
  "sprite": "/static/sprites/290.png"
},

{
  "id": 291,
  "dex": 291,
  "name": "#291 Ninjask",
  "types": ["bug", "flying"],
  "height": 0.8,
  "weight": 12.0,
  "sprite": "/static/sprites/291.png"
},

{
  "id": 292,
  "dex": 292,
  "name": "#292 Shedinja",
  "types": ["bug", "ghost"],
  "height": 0.8,
  "weight": 1.2,
  "sprite": "/static/sprites/292.png"
},

{
  "id": 293,
  "dex": 293,
  "name": "#293 Whismur",
  "types": ["normal"],
  "height": 0.6,
  "weight": 16.3,
  "sprite": "/static/sprites/293.png"
},

{
  "id": 294,
  "dex": 294,
  "name": "#294 Loudred",
  "types": ["normal"],
  "height": 1.0,
  "weight": 40.5,
  "sprite": "/static/sprites/294.png"
},

{
  "id": 295,
  "dex": 295,
  "name": "#295 Exploud",
  "types": ["normal"],
  "height": 1.5,
  "weight": 84.0,
  "sprite": "/static/sprites/295.png"
},

{
  "id": 296,
  "dex": 296,
  "name": "#296 Makuhita",
  "types": ["fighting"],
  "height": 1.0,
  "weight": 86.4,
  "sprite": "/static/sprites/296.png"
},

{
  "id": 297,
  "dex": 297,
  "name": "#297 Hariyama",
  "types": ["fighting"],
  "height": 2.3,
  "weight": 253.8,
  "sprite": "/static/sprites/297.png"
},

{
  "id": 298,
  "dex": 298,
  "name": "#298 Azurill",
  "types": ["normal", "fairy"],
  "height": 0.2,
  "weight": 2.0,
  "sprite": "/static/sprites/298.png"
},

{
  "id": 299,
  "dex": 299,
  "name": "#299 Nosepass",
  "types": ["rock"],
  "height": 1.0,
  "weight": 97.0,
  "sprite": "/static/sprites/299.png"
},

{
  "id": 300,
  "dex": 300,
  "name": "#300 Skitty",
  "types": ["normal"],
  "height": 0.6,
  "weight": 11.0,
  "sprite": "/static/sprites/300.png"
},
{
  "id": 351,
  "dex": 351,
  "name": "#351 Castform (Normal)",
  "types": ["normal"],
  "height": 0.3,
  "weight": 0.8,
  "sprite": "/static/sprites/351.png"
},
{
  "id": 35101,
  "dex": 351,
  "name": "#351 Castform (Sunny)",
  "types": ["fire"],
  "height": 0.3,
  "weight": 0.8,
  "sprite": "/static/sprites/351-sunny.png"
},
{
  "id": 35102,
  "dex": 351,
  "name": "#351 Castform (Rainy)",
  "types": ["water"],
  "height": 0.3,
  "weight": 0.8,
  "sprite": "/static/sprites/351-rainy.png"
},
{
  "id": 35103,
  "dex": 351,
  "name": "#351 Castform (Snowy)",
  "types": ["ice"],
  "height": 0.3,
  "weight": 0.8,
  "sprite": "/static/sprites/351-snowy.png"
},

{
  "id": 352,
  "dex": 352,
  "name": "#352 Kecleon",
  "types": ["normal"],
  "height": 1.0,
  "weight": 22.0,
  "sprite": "/static/sprites/352.png"
},

{
  "id": 353,
  "dex": 353,
  "name": "#353 Shuppet",
  "types": ["ghost"],
  "height": 0.6,
  "weight": 2.3,
  "sprite": "/static/sprites/353.png"
},

{
  "id": 354,
  "dex": 354,
  "name": "#354 Banette",
  "types": ["ghost"],
  "height": 1.1,
  "weight": 12.5,
  "sprite": "/static/sprites/354.png"
},
{
  "id": 35401,
  "dex": 354,
  "name": "#354 Banette Mega",
  "types": ["ghost"],
  "height": 1.2,
  "weight": 13.0,
  "sprite": "/static/sprites/354-mega.png"
},

{
  "id": 355,
  "dex": 355,
  "name": "#355 Duskull",
  "types": ["ghost"],
  "height": 0.8,
  "weight": 15.0,
  "sprite": "/static/sprites/355.png"
},

{
  "id": 356,
  "dex": 356,
  "name": "#356 Dusclops",
  "types": ["ghost"],
  "height": 1.6,
  "weight": 30.6,
  "sprite": "/static/sprites/356.png"
},

{
  "id": 357,
  "dex": 357,
  "name": "#357 Tropius",
  "types": ["grass", "flying"],
  "height": 2.0,
  "weight": 100.0,
  "sprite": "/static/sprites/357.png"
},

{
  "id": 358,
  "dex": 358,
  "name": "#358 Chimecho",
  "types": ["psychic"],
  "height": 0.6,
  "weight": 1.0,
  "sprite": "/static/sprites/358.png"
},

{
  "id": 359,
  "dex": 359,
  "name": "#359 Absol",
  "types": ["dark"],
  "height": 1.2,
  "weight": 47.0,
  "sprite": "/static/sprites/359.png"
},
{
  "id": 35901,
  "dex": 359,
  "name": "#359 Absol Mega",
  "types": ["dark"],
  "height": 1.2,
  "weight": 49.0,
  "sprite": "/static/sprites/359-mega.png"
},

{
  "id": 360,
  "dex": 360,
  "name": "#360 Wynaut",
  "types": ["psychic"],
  "height": 0.6,
  "weight": 14.0,
  "sprite": "/static/sprites/360.png"
},

{
  "id": 361,
  "dex": 361,
  "name": "#361 Snorunt",
  "types": ["ice"],
  "height": 0.7,
  "weight": 16.8,
  "sprite": "/static/sprites/361.png"
},

{
  "id": 362,
  "dex": 362,
  "name": "#362 Glalie",
  "types": ["ice"],
  "height": 1.5,
  "weight": 256.5,
  "sprite": "/static/sprites/362.png"
},
{
  "id": 36201,
  "dex": 362,
  "name": "#362 Glalie Mega",
  "types": ["ice"],
  "height": 2.1,
  "weight": 350.2,
  "sprite": "/static/sprites/362-mega.png"
},

{
  "id": 363,
  "dex": 363,
  "name": "#363 Spheal",
  "types": ["ice", "water"],
  "height": 0.8,
  "weight": 39.5,
  "sprite": "/static/sprites/363.png"
},

{
  "id": 364,
  "dex": 364,
  "name": "#364 Sealeo",
  "types": ["ice", "water"],
  "height": 1.1,
  "weight": 87.6,
  "sprite": "/static/sprites/364.png"
},

{
  "id": 365,
  "dex": 365,
  "name": "#365 Walrein",
  "types": ["ice", "water"],
  "height": 1.4,
  "weight": 150.6,
  "sprite": "/static/sprites/365.png"
},

{
  "id": 366,
  "dex": 366,
  "name": "#366 Clamperl",
  "types": ["water"],
  "height": 0.4,
  "weight": 52.5,
  "sprite": "/static/sprites/366.png"
},

{
  "id": 367,
  "dex": 367,
  "name": "#367 Huntail",
  "types": ["water"],
  "height": 1.7,
  "weight": 27.0,
  "sprite": "/static/sprites/367.png"
},

{
  "id": 368,
  "dex": 368,
  "name": "#368 Gorebyss",
  "types": ["water"],
  "height": 1.8,
  "weight": 22.6,
  "sprite": "/static/sprites/368.png"
},

{
  "id": 369,
  "dex": 369,
  "name": "#369 Relicanth",
  "types": ["water", "rock"],
  "height": 1.0,
  "weight": 23.4,
  "sprite": "/static/sprites/369.png"
},

{
  "id": 370,
  "dex": 370,
  "name": "#370 Luvdisc",
  "types": ["water"],
  "height": 0.6,
  "weight": 8.7,
  "sprite": "/static/sprites/370.png"
},

{
  "id": 371,
  "dex": 371,
  "name": "#371 Bagon",
  "types": ["dragon"],
  "height": 0.6,
  "weight": 42.1,
  "sprite": "/static/sprites/371.png"
},

{
  "id": 372,
  "dex": 372,
  "name": "#372 Shelgon",
  "types": ["dragon"],
  "height": 1.1,
  "weight": 110.5,
  "sprite": "/static/sprites/372.png"
},

{
  "id": 373,
  "dex": 373,
  "name": "#373 Salamence",
  "types": ["dragon", "flying"],
  "height": 1.5,
  "weight": 102.6,
  "sprite": "/static/sprites/373.png"
},
{
  "id": 37301,
  "dex": 373,
  "name": "#373 Salamence Mega",
  "types": ["dragon", "flying"],
  "height": 1.8,
  "weight": 112.6,
  "sprite": "/static/sprites/373-mega.png"
},

{
  "id": 374,
  "dex": 374,
  "name": "#374 Beldum",
  "types": ["steel", "psychic"],
  "height": 0.6,
  "weight": 95.2,
  "sprite": "/static/sprites/374.png"
},

{
  "id": 375,
  "dex": 375,
  "name": "#375 Metang",
  "types": ["steel", "psychic"],
  "height": 1.2,
  "weight": 202.5,
  "sprite": "/static/sprites/375.png"
},

{
  "id": 376,
  "dex": 376,
  "name": "#376 Metagross",
  "types": ["steel", "psychic"],
  "height": 1.6,
  "weight": 550.0,
  "sprite": "/static/sprites/376.png"
},
{
  "id": 37601,
  "dex": 376,
  "name": "#376 Metagross Mega",
  "types": ["steel", "psychic"],
  "height": 1.6,
  "weight": 942.9,
  "sprite": "/static/sprites/376-mega.png"
},

{
  "id": 377,
  "dex": 377,
  "name": "#377 Regirock",
  "types": ["rock"],
  "height": 1.7,
  "weight": 230.0,
  "sprite": "/static/sprites/377.png"
},

{
  "id": 378,
  "dex": 378,
  "name": "#378 Regice",
  "types": ["ice"],
  "height": 1.8,
  "weight": 175.0,
  "sprite": "/static/sprites/378.png"
},

{
  "id": 379,
  "dex": 379,
  "name": "#379 Registeel",
  "types": ["steel"],
  "height": 1.9,
  "weight": 205.0,
  "sprite": "/static/sprites/379.png"
},

{
  "id": 380,
  "dex": 380,
  "name": "#380 Latias",
  "types": ["dragon", "psychic"],
  "height": 1.4,
  "weight": 40.0,
  "sprite": "/static/sprites/380.png"
},
{
  "id": 38001,
  "dex": 380,
  "name": "#380 Latias Mega",
  "types": ["dragon", "psychic"],
  "height": 1.8,
  "weight": 52.0,
  "sprite": "/static/sprites/380-mega.png"
},

{
  "id": 381,
  "dex": 381,
  "name": "#381 Latios",
  "types": ["dragon", "psychic"],
  "height": 2.0,
  "weight": 60.0,
  "sprite": "/static/sprites/381.png"
},
{
  "id": 38101,
  "dex": 381,
  "name": "#381 Latios Mega",
  "types": ["dragon", "psychic"],
  "height": 2.3,
  "weight": 70.0,
  "sprite": "/static/sprites/381-mega.png"
},

{
  "id": 382,
  "dex": 382,
  "name": "#382 Kyogre",
  "types": ["water"],
  "height": 4.5,
  "weight": 352.0,
  "sprite": "/static/sprites/382.png"
},
{
  "id": 38201,
  "dex": 382,
  "name": "#382 Kyogre Primal",
  "types": ["water"],
  "height": 9.8,
  "weight": 430.0,
  "sprite": "/static/sprites/382-primal.png"
},

{
  "id": 383,
  "dex": 383,
  "name": "#383 Groudon",
  "types": ["ground"],
  "height": 3.5,
  "weight": 950.0,
  "sprite": "/static/sprites/383.png"
},
{
  "id": 38301,
  "dex": 383,
  "name": "#383 Groudon Primal",
  "types": ["ground", "fire"],
  "height": 5.0,
  "weight": 999.7,
  "sprite": "/static/sprites/383-primal.png"
},

{
  "id": 384,
  "dex": 384,
  "name": "#384 Rayquaza",
  "types": ["dragon", "flying"],
  "height": 7.0,
  "weight": 206.5,
  "sprite": "/static/sprites/384.png"
},
{
  "id": 38401,
  "dex": 384,
  "name": "#384 Rayquaza Mega",
  "types": ["dragon", "flying"],
  "height": 10.8,
  "weight": 392.0,
  "sprite": "/static/sprites/384-mega.png"
},

{
  "id": 385,
  "dex": 385,
  "name": "#385 Jirachi",
  "types": ["steel", "psychic"],
  "height": 0.3,
  "weight": 1.1,
  "sprite": "/static/sprites/385.png"
},

{
  "id": 386,
  "dex": 386,
  "name": "#386 Deoxys (Normal)",
  "types": ["psychic"],
  "height": 1.7,
  "weight": 60.8,
  "sprite": "/static/sprites/386.png"
},
{
  "id": 38601,
  "dex": 386,
  "name": "#386 Deoxys (Attack)",
  "types": ["psychic"],
  "height": 1.7,
  "weight": 60.8,
  "sprite": "/static/sprites/386-attack.png"
},
{
  "id": 38602,
  "dex": 386,
  "name": "#386 Deoxys (Defense)",
  "types": ["psychic"],
  "height": 1.7,
  "weight": 60.8,
  "sprite": "/static/sprites/386-defense.png"
},
{
  "id": 38603,
  "dex": 386,
  "name": "#386 Deoxys (Speed)",
  "types": ["psychic"],
  "height": 1.7,
  "weight": 60.8,
  "sprite": "/static/sprites/386-speed.png"
},

{
  "id": 387,
  "dex": 387,
  "name": "#387 Turtwig",
  "types": ["grass"],
  "height": 0.4,
  "weight": 10.2,
  "sprite": "/static/sprites/387.png"
},

{
  "id": 388,
  "dex": 388,
  "name": "#388 Grotle",
  "types": ["grass"],
  "height": 1.1,
  "weight": 97.0,
  "sprite": "/static/sprites/388.png"
},

{
  "id": 389,
  "dex": 389,
  "name": "#389 Torterra",
  "types": ["grass", "ground"],
  "height": 2.2,
  "weight": 310.0,
  "sprite": "/static/sprites/389.png"
},

{
  "id": 390,
  "dex": 390,
  "name": "#390 Chimchar",
  "types": ["fire"],
  "height": 0.5,
  "weight": 6.2,
  "sprite": "/static/sprites/390.png"
},

{
  "id": 391,
  "dex": 391,
  "name": "#391 Monferno",
  "types": ["fire", "fighting"],
  "height": 0.9,
  "weight": 22.0,
  "sprite": "/static/sprites/391.png"
},

{
  "id": 392,
  "dex": 392,
  "name": "#392 Infernape",
  "types": ["fire", "fighting"],
  "height": 1.2,
  "weight": 55.0,
  "sprite": "/static/sprites/392.png"
},

{
  "id": 393,
  "dex": 393,
  "name": "#393 Piplup",
  "types": ["water"],
  "height": 0.4,
  "weight": 5.2,
  "sprite": "/static/sprites/393.png"
},

{
  "id": 394,
  "dex": 394,
  "name": "#394 Prinplup",
  "types": ["water"],
  "height": 0.8,
  "weight": 23.0,
  "sprite": "/static/sprites/394.png"
},

{
  "id": 395,
  "dex": 395,
  "name": "#395 Empoleon",
  "types": ["water", "steel"],
  "height": 1.7,
  "weight": 84.5,
  "sprite": "/static/sprites/395.png"
},

{
  "id": 396,
  "dex": 396,
  "name": "#396 Starly",
  "types": ["normal", "flying"],
  "height": 0.3,
  "weight": 2.0,
  "sprite": "/static/sprites/396.png"
},

{
  "id": 397,
  "dex": 397,
  "name": "#397 Staravia",
  "types": ["normal", "flying"],
  "height": 0.6,
  "weight": 15.5,
  "sprite": "/static/sprites/397.png"
},

{
  "id": 398,
  "dex": 398,
  "name": "#398 Staraptor",
  "types": ["normal", "flying"],
  "height": 1.2,
  "weight": 24.9,
  "sprite": "/static/sprites/398.png"
},

{
  "id": 399,
  "dex": 399,
  "name": "#399 Bidoof",
  "types": ["normal"],
  "height": 0.5,
  "weight": 20.0,
  "sprite": "/static/sprites/399.png"
},

{
  "id": 400,
  "dex": 400,
  "name": "#400 Bibarel",
  "types": ["normal", "water"],
  "height": 1.0,
  "weight": 31.5,
  "sprite": "/static/sprites/400.png"
},






}

# ---------------------------------------------
# 2. Função para carregar pokédex offline parcial
# ---------------------------------------------
def load_offline_pokedex():
    global POKEDEX
    # Quando você aprovar, eu gero a versão completa aqui.
    # A estrutura é assim:
    """
    POKEDEX = {
        1: {"name": "Bulbassauro", "types": ["grass","poison"], "height": 0.7, "weight": 6.9},
        2: {"name": "Ivysaur", ...},
        ...
        1025: {...}
    }
    """
    pass


# -------------------------------
# 3. Corrigir JSON base
# -------------------------------
def corrigir_json():
    # Carregar JSON original
    with open("pokemon_static_fixed.json", "r", encoding="utf-8") as f:
        base = json.load(f)

    # Ler lista de IDs faltando
    missing = []
    with open("missing_manual_fill.txt", "r", encoding="utf-8") as f:
        for line in f:
            m = re.findall(r"ID\s+(\d+)", line)
            if m:
                missing.append(int(m[0]))

    print(f"Corrigindo {len(missing)} Pokémon...")

    for p in base:
        pid = p["id"]

        if pid not in missing:
            continue

        if pid not in POKEDEX:
            print(f"[ERRO] Pokémon {pid} não encontrado no banco offline.")
            continue

        info = POKEDEX[pid]

        p["name"] = f"#{pid:03d} {info['name']}"
        p["types"] = info["types"]
        p["height"] = info["height"]
        p["weight"] = info["weight"]

    # Gravar arquivo final
    with open("pokemon_static_fixed_CORRIGIDO.json", "w", encoding="utf-8") as f:
        json.dump(base, f, indent=2, ensure_ascii=False)

    print("\n🎉 Arquivo gerado: pokemon_static_fixed_CORRIGIDO.json")


if __name__ == "__main__":
    load_offline_pokedex()
    corrigir_json()
