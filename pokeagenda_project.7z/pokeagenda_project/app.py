import os, json, sqlite3
from flask import Flask, render_template, request, jsonify, redirect, url_for

app = Flask(__name__)
app.secret_key = "pokeagenda_offline"

ROOT = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(ROOT, "pokemon_static_fixed.json")  
DATABASE = os.path.join(ROOT, "pokeagenda.db")

# Carrega JSON uma vez na inicialização
if os.path.exists(JSON_PATH):
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        POKEMON_DATA = json.load(f)
else:
    POKEMON_DATA = []

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS Treinador (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            email TEXT,
            cpf TEXT,
            foto TEXT,
            cidade TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS Treinador_Pokemon (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            treinador_id INTEGER,
            pokemon_id INTEGER,
            local TEXT CHECK(local IN ('time','box')),
            apelido TEXT
        )
    """)
    # Garantir treinador padrão
    count = c.execute("SELECT COUNT(*) FROM Treinador").fetchone()[0]
    if count == 0:
        c.execute("INSERT INTO Treinador (nome, email, cpf, foto, cidade) VALUES (?, ?, ?, ?, ?)",
                 ("Ash Ketchum", "ash@pokemon.com", "123.456.789-00", "/static/sprites/25.png", "Pallet Town"))
    conn.commit()
    conn.close()

@app.route("/")
def index():
    conn = get_db_connection()
    treinador = conn.execute("SELECT * FROM Treinador LIMIT 1").fetchone()
    conn.close()
    return render_template("index.html", treinador=treinador)

@app.route("/perfil")
def perfil():
    conn = get_db_connection()
    treinador = conn.execute("SELECT * FROM Treinador LIMIT 1").fetchone()
    conn.close()
    return render_template("perfil.html", treinador=treinador)

@app.route("/editar-perfil", methods=["POST"])
def editar_perfil():
    nome = request.form.get("nome")
    email = request.form.get("email")
    cidade = request.form.get("cidade")
    foto = request.form.get("foto")
    conn = get_db_connection()
    conn.execute("UPDATE Treinador SET nome=?, email=?, cidade=?, foto=? WHERE id=1", (nome, email, cidade, foto))
    conn.commit()
    conn.close()
    return redirect(url_for("perfil"))

# Páginas da Pokédex
@app.route("/pokedex")
def pokedex():
    # template cliente requisitará páginas via /api/pokedex
    return render_template("pokedex.html")

@app.route("/api/pokedex")
def api_pokedex():
    # Paginação server-side
    try:
        page = int(request.args.get("page", "1"))
    except:
        page = 1
    try:
        page_size = int(request.args.get("page_size", "60"))
    except:
        page_size = 60
    start = (page - 1) * page_size
    end = start + page_size
    slice_ = POKEMON_DATA[start:end]
    total = len(POKEMON_DATA)
    return jsonify({"results": slice_, "total": total})

@app.route("/api/pokedex/search")
def api_search():
    q = request.args.get("q", "").strip().lower()
    limit = int(request.args.get("limit", "200"))
    if not q:
        return jsonify([])
    results = []
    for p in POKEMON_DATA:
        if q == str(p.get("id")) or q in p.get("name","").lower() or q in " ".join(p.get("types",[])).lower():
            results.append(p)
            if len(results) >= limit:
                break
    return jsonify(results)

# Meu time e ações 
@app.route("/meu-time")
def meu_time():
    conn = get_db_connection()
    treinador = conn.execute("SELECT * FROM Treinador LIMIT 1").fetchone()
    time = conn.execute("SELECT * FROM Treinador_Pokemon WHERE treinador_id=1 AND local='time'").fetchall()
    box = conn.execute("SELECT * FROM Treinador_Pokemon WHERE treinador_id=1 AND local='box'").fetchall()
    conn.close()
    # get_pokemon helper for template
    def get_pokemon(pid):
        return next((x for x in POKEMON_DATA if int(x['id'])==int(pid)), None)
    return render_template("meu_time.html", todos=POKEMON_DATA, time=time, box=box, get_pokemon=get_pokemon)

@app.route("/api/adicionar", methods=["POST"])
def adicionar():
    data = request.get_json() or {}
    pokemon_id = int(data.get("pokemon_id"))
    apelido = data.get("apelido","") or ""
    conn = get_db_connection()
    count = conn.execute("SELECT COUNT(*) FROM Treinador_Pokemon WHERE treinador_id=1 AND local='time'").fetchone()[0]
    local = "time" if count < 6 else "box"
    conn.execute("INSERT INTO Treinador_Pokemon (treinador_id, pokemon_id, local, apelido) VALUES (1,?,?,?)", (pokemon_id, local, apelido))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "local": local})

@app.route("/api/remover", methods=["POST"])
def remover():
    data = request.get_json() or {}
    rel_id = data.get("rel_id")
    conn = get_db_connection()
    conn.execute("DELETE FROM Treinador_Pokemon WHERE id=?", (rel_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route("/api/mover", methods=["POST"])
def mover():
    data = request.get_json() or {}
    rel_id = data.get("rel_id")
    destino = data.get("destino")
    conn = get_db_connection()
    if destino == "time":
        count = conn.execute("SELECT COUNT(*) FROM Treinador_Pokemon WHERE treinador_id=1 AND local='time'").fetchone()[0]
        if count >= 6:
            conn.close()
            return jsonify({"success": False, "error": "Time cheio."})
    conn.execute("UPDATE Treinador_Pokemon SET local=? WHERE id=?", (destino, rel_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
