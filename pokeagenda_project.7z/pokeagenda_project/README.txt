Projeto quase concluído: 
1- falta completar a POKEDEX={400-1025 + formas restantes} em corrigir_pokemon_json.py para corrigir o problema do nome dos pokemon estar genérico.
2- arrumar o css.
3- (talvez)criar uma página padrão para poder clicar nos pokemon da pokedex e aparecer as características dele.

O que já tem:
1. Página inicial, Pokedex(quase funcionando), Meu time, Perfil.
2. Poder adicionar, mover e remover um pokemon do time ou box.
3. funciona offline pois tem BD e os pokemon são pegados de uma lista json (pokemon_static_fixed.json)


To run:
1.  criar ambiente virtual e instalar flask:
   python -m venv venv
   venv\Scripts\activate 
   pip install flask

2. Run the app:
   python app.py

